<?php

/**
 * Test fixture.
 *
 * Used in the `PHPMailer\LocalizationTest` to test the fall-back logic.
 */

$PHPMAILER_LANG['empty_message'] = 'XA Lang-script-country file found';
